require("dotenv").config();

const express = require("express");
const cors = require("cors");
const nodemailer = require("nodemailer");
const multer = require("multer");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const crypto = require("crypto");

const {
  S3Client,
  PutObjectCommand,
  GetObjectCommand
} = require("@aws-sdk/client-s3");

const {
  DynamoDBClient
} = require("@aws-sdk/client-dynamodb");

const {
  DynamoDBDocumentClient,
  PutCommand,
  GetCommand,
  ScanCommand,
  UpdateCommand
} = require("@aws-sdk/lib-dynamodb");

const {
  RekognitionClient,
  CreateCollectionCommand,
  DescribeCollectionCommand,
  IndexFacesCommand,
  SearchFacesByImageCommand,
  DeleteFacesCommand
} = require("@aws-sdk/client-rekognition");

const app = express();

// ==================================================
// CONFIGURATION
// ==================================================

const PORT = Number(process.env.PORT || 5000);

const REGION = process.env.AWS_REGION || "ap-south-1";

const S3_BUCKET =
  process.env.AWS_S3_BUCKET ||
  process.env.S3_BUCKET;

const PERSONS_TABLE =
  process.env.DYNAMODB_TABLE || "MissingPersons";

const USERS_TABLE =
  process.env.USERS_TABLE || "AppUsers";

const COLLECTION_ID =
  process.env.REKOGNITION_COLLECTION ||
  "missing-person-faces";

const JWT_SECRET = process.env.JWT_SECRET;

if (!S3_BUCKET) {
  throw new Error(
    "S3_BUCKET or AWS_S3_BUCKET is missing from your .env file."
  );
}

if (!JWT_SECRET || JWT_SECRET.length < 32) {
  throw new Error(
    "JWT_SECRET must contain at least 32 characters."
  );
}

// ==================================================
// AWS CLIENTS
// ==================================================

const s3 = new S3Client({
  region: REGION
});

const dynamoClient = new DynamoDBClient({
  region: REGION
});

const dynamodb = DynamoDBDocumentClient.from(
  dynamoClient,
  {
    marshallOptions: {
      removeUndefinedValues: true
    }
  }
);

const rekognition = new RekognitionClient({
  region: REGION
});

// ==================================================
// EXPRESS MIDDLEWARE
// ==================================================

app.use(
  cors({
    origin: [
      "http://localhost:5173",
      "http://localhost:5174"
    ]
  })
);

app.use(express.json());

const upload = multer({
  storage: multer.memoryStorage(),

  limits: {
    fileSize: 5 * 1024 * 1024
  },

  fileFilter: (req, file, callback) => {
    if (!file.mimetype.startsWith("image/")) {
      return callback(
        new Error("Please upload an image file.")
      );
    }

    callback(null, true);
  }
});

// ==================================================
// AUTHENTICATION MIDDLEWARE
// ==================================================

function requireAuth(req, res, next) {
  const authorization = req.headers.authorization;

  if (!authorization || !authorization.startsWith("Bearer ")) {
    return res.status(401).json({
      success: false,
      message: "Authentication required. Please sign in."
    });
  }

  const token = authorization.split(" ")[1];

  try {
    req.user = jwt.verify(token, JWT_SECRET);
    next();
  } catch (error) {
    return res.status(401).json({
      success: false,
      message: "Your session has expired. Please sign in again."
    });
  }
}

// ==================================================
// CREATE REKOGNITION COLLECTION IF NECESSARY
// ==================================================

async function ensureCollection() {
  try {
    await rekognition.send(
      new DescribeCollectionCommand({
        CollectionId: COLLECTION_ID
      })
    );

    console.log(
      `Rekognition collection "${COLLECTION_ID}" is available.`
    );
  } catch (error) {
    if (error.name !== "ResourceNotFoundException") {
      throw error;
    }

    await rekognition.send(
      new CreateCollectionCommand({
        CollectionId: COLLECTION_ID
      })
    );

    console.log(
      `Created Rekognition collection "${COLLECTION_ID}".`
    );
  }
}

// ==================================================
// HEALTH CHECK
// ==================================================

app.get("/", (req, res) => {
  res.json({
    success: true,
    message: "Missing Person Identification API is running."
  });
});

// ==================================================
// SIGNUP
// ==================================================

app.post("/api/auth/signup", async (req, res) => {
  try {
    const email = String(req.body.email || "")
      .trim()
      .toLowerCase();

    const password = String(req.body.password || "");

    if (!email || !email.includes("@")) {
      return res.status(400).json({
        success: false,
        message: "Please enter a valid email address."
      });
    }

    if (password.length < 12) {
      return res.status(400).json({
        success: false,
        message: "Password must contain at least 12 characters."
      });
    }

    // Check whether the email already exists.
    let lastEvaluatedKey;

    do {
      const scanResponse = await dynamodb.send(
        new ScanCommand({
          TableName: USERS_TABLE,
          ProjectionExpression: "userId, email",
          ExclusiveStartKey: lastEvaluatedKey
        })
      );

      const existingUser = (scanResponse.Items || []).find(
        user =>
          String(user.email || "").toLowerCase() === email
      );

      if (existingUser) {
        return res.status(409).json({
          success: false,
          message: "An account with this email already exists. Please sign in."
        });
      }

      lastEvaluatedKey = scanResponse.LastEvaluatedKey;

    } while (lastEvaluatedKey);

    const userId = crypto.randomUUID();

    const passwordHash = await bcrypt.hash(
      password,
      12
    );

    const user = {
      userId,
      email,
      passwordHash,
      role: "investigator",
      createdAt: new Date().toISOString()
    };

    await dynamodb.send(
      new PutCommand({
        TableName: USERS_TABLE,
        Item: user,

        ConditionExpression:
          "attribute_not_exists(userId)"
      })
    );

    const token = jwt.sign(
      {
        userId,
        email,
        role: "investigator"
      },
      JWT_SECRET,
      {
        expiresIn: "8h"
      }
    );

    return res.status(201).json({
      success: true,
      message: "Account created successfully.",
      token,
      user: {
        userId,
        email,
        role: "investigator"
      }
    });

  } catch (error) {
    console.error("Signup error:", error);

    return res.status(500).json({
      success: false,
      message: "Signup failed.",
      error: error.message
    });
  }
});

// ==================================================
// LOGIN
// ==================================================

app.post("/api/auth/login", async (req, res) => {
  try {
    const email = String(req.body.email || "")
      .trim()
      .toLowerCase();

    const password = String(req.body.password || "");

    if (!email || !password) {
      return res.status(400).json({
        success: false,
        message: "Enter your email and password."
      });
    }

    let lastEvaluatedKey;
    let user = null;

    do {
      const response = await dynamodb.send(
        new ScanCommand({
          TableName: USERS_TABLE,
          ProjectionExpression:
            "userId, email, passwordHash, #role",
          ExpressionAttributeNames: {
            "#role": "role"
          },
          ExclusiveStartKey: lastEvaluatedKey
        })
      );

      user = (response.Items || []).find(
        item =>
          String(item.email || "").toLowerCase() === email
      );

      lastEvaluatedKey = response.LastEvaluatedKey;

    } while (!user && lastEvaluatedKey);

    if (
      !user ||
      !user.passwordHash ||
      !(await bcrypt.compare(password, user.passwordHash))
    ) {
      return res.status(401).json({
        success: false,
        message: "Invalid email or password."
      });
    }

    const token = jwt.sign(
      {
        userId: user.userId,
        email: user.email,
        role: user.role || "investigator"
      },
      JWT_SECRET,
      {
        expiresIn: "8h"
      }
    );

    return res.json({
      success: true,
      message: "Login successful.",
      token,
      user: {
        userId: user.userId,
        email: user.email,
        role: user.role || "investigator"
      }
    });

  } catch (error) {
    console.error("Login error:", error);

    return res.status(500).json({
      success: false,
      message: "Login failed.",
      error: error.message
    });
  }
});
// ==================================================
// FORGOT PASSWORD AND RESET PASSWORD
// ==================================================

function createMailTransport() {
  const smtpUser = process.env.SMTP_USER;
  const smtpPass = (process.env.SMTP_PASS || "").replace(/\s+/g, "");

  if (!smtpUser || !smtpPass) {
    throw new Error(
      "Email is not configured. Set SMTP_USER and SMTP_PASS in backend/.env."
    );
  }

  return nodemailer.createTransport({
    host: process.env.SMTP_HOST || "smtp.gmail.com",
    port: Number(process.env.SMTP_PORT || 465),
    secure:
      String(process.env.SMTP_SECURE || "true").toLowerCase() === "true",
    auth: {
      user: smtpUser,
      pass: smtpPass
    }
  });
}

// ==================================================
// FORGOT PASSWORD
// POST /api/auth/forgot-password
// ==================================================

app.post("/api/auth/forgot-password", async (req, res) => {
  try {
    const email = String(req.body.email || "")
      .trim()
      .toLowerCase();

    if (!email || !email.includes("@")) {
      return res.status(400).json({
        success: false,
        message: "Please enter a valid email address."
      });
    }

    let lastEvaluatedKey;
    let user = null;

    do {
      const response = await dynamodb.send(
        new ScanCommand({
          TableName: USERS_TABLE,
          ProjectionExpression: "userId, email",
          ExclusiveStartKey: lastEvaluatedKey
        })
      );

      user = (response.Items || []).find(
        item =>
          String(item.email || "").trim().toLowerCase() === email
      ) || null;

      lastEvaluatedKey = response.LastEvaluatedKey;
    } while (!user && lastEvaluatedKey);

    // Do not disclose whether an account exists.
    if (!user) {
      return res.json({
        success: true,
        message:
          "If an account exists for this email, a reset link will be sent."
      });
    }

    // Generate a secure, random reset token.
    const rawToken = crypto.randomBytes(32).toString("hex");

    // Store only the hash of the token in DynamoDB.
    const tokenHash = crypto
      .createHash("sha256")
      .update(rawToken)
      .digest("hex");

    // Token expires after 15 minutes.
    const expiresAt = Date.now() + 15 * 60 * 1000;

    await dynamodb.send(
      new UpdateCommand({
        TableName: USERS_TABLE,
        Key: {
          userId: user.userId
        },
        UpdateExpression:
          "SET resetTokenHash = :tokenHash, resetTokenExpiresAt = :expiresAt",
        ExpressionAttributeValues: {
          ":tokenHash": tokenHash,
          ":expiresAt": expiresAt
        },
        ConditionExpression: "attribute_exists(userId)"
      })
    );

    const frontendUrl = (
      process.env.FRONTEND_URL || "http://localhost:5173"
    ).replace(/\/+$/, "");

    // Your React app reads the token from the URL query string.
    const resetLink =
      `${frontendUrl}/?token=${encodeURIComponent(rawToken)}`;

    const transporter = createMailTransport();

    await transporter.sendMail({
      from:
        `"Missing Person Identification System" <${process.env.SMTP_USER}>`,
      to: email,
      subject: "Reset your password",

      text:
        "We received a request to reset your password.\n\n" +
        `Open this link within 15 minutes to choose a new password:\n${resetLink}\n\n` +
        "If you did not request this, you can ignore this email.",

      html:
        "<p>We received a request to reset your password.</p>" +
        `<p><a href="${resetLink}">Reset your password</a></p>` +
        "<p>This link expires in 15 minutes. If you did not request this, you can ignore this email.</p>"
    });

    return res.json({
      success: true,
      message:
        "If an account exists for this email, a reset link will be sent."
    });

  } catch (error) {
    console.error("Forgot password error:", error);

    return res.status(500).json({
      success: false,
      message:
        "Could not send the password-reset email. Check the backend SMTP configuration.",
      error: error.message
    });
  }
});

// ==================================================
// RESET PASSWORD
// POST /api/auth/reset-password
// ==================================================

app.post("/api/auth/reset-password", async (req, res) => {
  try {
    const token = String(req.body.token || "").trim();
    const newPassword = String(req.body.newPassword || "");

    if (!token) {
      return res.status(400).json({
        success: false,
        message: "The password-reset token is missing."
      });
    }

    if (newPassword.length < 12 || newPassword.length > 72) {
      return res.status(400).json({
        success: false,
        message:
          "Password must contain between 12 and 72 characters."
      });
    }

    // Hash the token received from the reset page.
    const tokenHash = crypto
      .createHash("sha256")
      .update(token)
      .digest("hex");

    let lastEvaluatedKey;
    let matchedUser = null;

    // Find the account associated with this reset token.
    do {
      const response = await dynamodb.send(
        new ScanCommand({
          TableName: USERS_TABLE,
          ProjectionExpression:
            "userId, resetTokenHash, resetTokenExpiresAt",
          ExclusiveStartKey: lastEvaluatedKey
        })
      );

      matchedUser = (response.Items || []).find(
        item => item.resetTokenHash === tokenHash
      ) || null;

      lastEvaluatedKey = response.LastEvaluatedKey;
    } while (!matchedUser && lastEvaluatedKey);

    // Reject invalid or expired tokens.
    if (
      !matchedUser ||
      !matchedUser.resetTokenExpiresAt ||
      Number(matchedUser.resetTokenExpiresAt) < Date.now()
    ) {
      return res.status(400).json({
        success: false,
        message:
          "This reset link is invalid or has expired. Please request a new one."
      });
    }

    // Hash the new password using the same algorithm as signup.
    const passwordHash = await bcrypt.hash(newPassword, 12);

    // Update the password and invalidate the reset token.
    await dynamodb.send(
      new UpdateCommand({
        TableName: USERS_TABLE,

        Key: {
          userId: matchedUser.userId
        },

        UpdateExpression:
          "SET passwordHash = :passwordHash " +
          "REMOVE resetTokenHash, resetTokenExpiresAt",

        ConditionExpression:
          "resetTokenHash = :tokenHash AND resetTokenExpiresAt >= :now",

        ExpressionAttributeValues: {
          ":passwordHash": passwordHash,
          ":tokenHash": tokenHash,
          ":now": Date.now()
        }
      })
    );

    return res.json({
      success: true,
      message:
        "Password reset successfully. You can now sign in with your new password."
    });

  } catch (error) {
    console.error("Reset password error:", error);

    return res.status(500).json({
      success: false,
      message: "Could not reset the password.",
      error: error.message
    });
  }
});
// ==================================================
// GET CURRENT USER
// ==================================================

app.get("/api/auth/me", requireAuth, async (req, res) => {
  try {
    const response = await dynamodb.send(
      new GetCommand({
        TableName: USERS_TABLE,
        Key: {
          userId: req.user.userId
        }
      })
    );

    if (!response.Item) {
      return res.status(404).json({
        success: false,
        message: "User account not found."
      });
    }

    return res.json({
      success: true,
      user: {
        userId: response.Item.userId,
        email: response.Item.email,
        role: response.Item.role
      }
    });

  } catch (error) {
    console.error("Current user error:", error);

    return res.status(500).json({
      success: false,
      message: "Could not retrieve user information."
    });
  }
});

// ==================================================
// REGISTER MISSING PERSON OR UNKNOWN PERSON
// ==================================================

app.post(
  "/api/persons",
  requireAuth,
  upload.single("photo"),
  async (req, res) => {
    let s3Key = null;
    let indexedFaceIds = [];

    try {
      const {
        recordType,
        fullName,
        age,
        gender,
        location,
        lastSeenLocation,
        dateReportedMissing,
        dateFound,
        description
      } = req.body;

      if (!req.file) {
        return res.status(400).json({
          success: false,
          message: "Please upload a photograph."
        });
      }

      if (!["missing", "unknown"].includes(recordType)) {
        return res.status(400).json({
          success: false,
          message: "Record type must be missing or unknown."
        });
      }

      if (recordType === "missing" && !fullName?.trim()) {
        return res.status(400).json({
          success: false,
          message: "Please enter the missing person's name."
        });
      }

      const personId = crypto.randomUUID();

      s3Key = `persons/${personId}/${crypto.randomUUID()}`;

      // 1. Upload photograph to S3.
      await s3.send(
        new PutObjectCommand({
          Bucket: S3_BUCKET,
          Key: s3Key,
          Body: req.file.buffer,
          ContentType: req.file.mimetype
        })
      );

      // 2. Index the face in Rekognition.
      const indexResponse = await rekognition.send(
        new IndexFacesCommand({
          CollectionId: COLLECTION_ID,

          Image: {
            Bytes: req.file.buffer
          },

          // This ID connects the face to its DynamoDB record.
          ExternalImageId: personId,

          MaxFaces: 1,
          QualityFilter: "AUTO",
          DetectionAttributes: []
        })
      );

      if (
        !indexResponse.FaceRecords ||
        indexResponse.FaceRecords.length === 0
      ) {
        return res.status(400).json({
          success: false,
          message:
            "No usable face was detected. Upload a clear photograph showing one person's face."
        });
      }

      indexedFaceIds = indexResponse.FaceRecords.map(
        record => record.Face.FaceId
      );

      // 3. Save person details in DynamoDB.
      const person = {
        personId,
        recordType,
        fullName:
          recordType === "unknown"
            ? "Unknown"
            : fullName.trim(),
        age: age ? Number(age) : null,
        gender: gender || "Not specified",
        location:
          location ||
          lastSeenLocation ||
          "Not specified",
        lastSeenLocation:
          lastSeenLocation || location || "",
        dateReportedMissing:
          dateReportedMissing || "",
        dateFound:
          dateFound || "",
        description: description || "",
        s3Key,
        faceIds: indexedFaceIds,
        createdAt: new Date().toISOString(),
        registeredBy: req.user.userId
      };

      await dynamodb.send(
        new PutCommand({
          TableName: PERSONS_TABLE,
          Item: person,

          ConditionExpression:
            "attribute_not_exists(personId)"
        })
      );

      return res.status(201).json({
        success: true,
        message:
          recordType === "unknown"
            ? "Unknown person registered successfully."
            : "Missing person registered successfully.",
        person: {
          personId,
          fullName: person.fullName,
          recordType,
          faceIndexed: true
        }
      });

    } catch (error) {
      console.error("Person registration error:", error);

      // Remove indexed faces if the database save failed.
      if (indexedFaceIds.length > 0) {
        try {
          await rekognition.send(
            new DeleteFacesCommand({
              CollectionId: COLLECTION_ID,
              FaceIds: indexedFaceIds
            })
          );
        } catch (cleanupError) {
          console.error(
            "Face cleanup error:",
            cleanupError.message
          );
        }
      }

      return res.status(500).json({
        success: false,
        message: "Person registration failed.",
        error: error.message
      });
    }
  }
);

// ==================================================
// LIST PERSON RECORDS
// ==================================================

app.get("/api/persons", requireAuth, async (req, res) => {
  try {
    const response = await dynamodb.send(
      new ScanCommand({
        TableName: PERSONS_TABLE
      })
    );

    const persons = (response.Items || []).map(person => ({
      personId: person.personId,
      recordType: person.recordType,
      fullName: person.fullName,
      age: person.age,
      gender: person.gender,
      location: person.location,
      dateReportedMissing: person.dateReportedMissing,
      dateFound: person.dateFound,
      description: person.description,
      createdAt: person.createdAt
    }));

    return res.json({
      success: true,
      persons
    });

  } catch (error) {
    console.error("List persons error:", error);

    return res.status(500).json({
      success: false,
      message: "Could not retrieve person records.",
      error: error.message
    });
  }
});

// ==================================================
// RETRIEVE A PRIVATE PHOTO FROM S3
// ==================================================

app.get(
  "/api/persons/:personId/photo",
  requireAuth,
  async (req, res) => {
    try {
      const response = await dynamodb.send(
        new GetCommand({
          TableName: PERSONS_TABLE,
          Key: {
            personId: req.params.personId
          }
        })
      );

      if (!response.Item || !response.Item.s3Key) {
        return res.status(404).json({
          success: false,
          message: "Photograph not found."
        });
      }

      const photo = await s3.send(
        new GetObjectCommand({
          Bucket: S3_BUCKET,
          Key: response.Item.s3Key
        })
      );

      res.setHeader(
        "Content-Type",
        photo.ContentType || "image/jpeg"
      );

      res.setHeader(
        "Cache-Control",
        "private, no-store"
      );

      const bytes = await photo.Body.transformToByteArray();

      return res.send(Buffer.from(bytes));

    } catch (error) {
      console.error("Photo retrieval error:", error);

      return res.status(500).json({
        success: false,
        message: "Could not retrieve photograph."
      });
    }
  }
);

// ==================================================
// AI FACE SEARCH
// ==================================================

app.post(
  "/api/search",
  requireAuth,
  upload.single("photo"),
  async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({
          success: false,
          message: "Please upload a photograph to search."
        });
      }

      const imageBuffer = req.file.buffer;

      // AWS Rekognition compares the uploaded face against
      // indexed faces in the configured collection.
      const searchResponse = await rekognition.send(
        new SearchFacesByImageCommand({
          CollectionId: COLLECTION_ID,

          Image: {
            Bytes: imageBuffer
          },

          // Return up to ten candidates.
          MaxFaces: 10,

          // Search with a less restrictive threshold.
          FaceMatchThreshold: 50
        })
      );

      const faceMatches = searchResponse.FaceMatches || [];

      if (faceMatches.length === 0) {
        return res.json({
          success: true,
          message:
            "No candidate faces were found. Try a clearer, front-facing photograph.",
          totalMatches: 0,
          matches: []
        });
      }

      const matches = [];

      // Retrieve each matching person's database record.
      for (const faceMatch of faceMatches) {
        const personId = faceMatch.Face?.ExternalImageId;

        if (!personId) {
          continue;
        }

        const personResponse = await dynamodb.send(
          new GetCommand({
            TableName: PERSONS_TABLE,
            Key: {
              personId
            }
          })
        );

        if (!personResponse.Item) {
          console.warn(
            `Indexed face has no DynamoDB record: ${personId}`
          );

          continue;
        }

        const person = personResponse.Item;

        matches.push({
          personId: person.personId,
          fullName: person.fullName || "Unknown",
          age: person.age ?? "Not available",
          gender: person.gender || "Not specified",
          location: person.location || "Not specified",
          recordType: person.recordType || "missing",
          dateReportedMissing:
            person.dateReportedMissing || "",
          dateFound: person.dateFound || "",
          description: person.description || "",

          // This is AWS's similarity score, not a probability.
          similarity: Number(
            faceMatch.Similarity.toFixed(2)
          )
        });
      }

      // Highest similarity score first.
      matches.sort(
        (a, b) => b.similarity - a.similarity
      );

      return res.json({
        success: true,
        message: matches.length
          ? "AI face search completed."
          : "Candidate faces were found, but their person records could not be retrieved.",
        totalMatches: matches.length,
        matches
      });

    } catch (error) {
      console.error("AI face search error:", error);

      return res.status(500).json({
        success: false,
        message: "AI face search failed.",
        error: error.message
      });
    }
  }
);

// ==================================================
// ERROR HANDLER
// ==================================================

app.use((error, req, res, next) => {
  console.error("Server error:", error);

  if (res.headersSent) {
    return next(error);
  }

  return res.status(500).json({
    success: false,
    message: error.message || "An unexpected server error occurred."
  });
});

// ==================================================
// START SERVER
// ==================================================

async function startServer() {
  try {
    await ensureCollection();

    app.listen(PORT, () => {
      console.log("---------------------------------------");
      console.log("Missing Person Identification API");
      console.log(`Server: http://localhost:${PORT}`);
      console.log(`AWS Region: ${REGION}`);
      console.log(`S3 Bucket: ${S3_BUCKET}`);
      console.log(`DynamoDB Persons Table: ${PERSONS_TABLE}`);
      console.log(`DynamoDB Users Table: ${USERS_TABLE}`);
      console.log(`Rekognition Collection: ${COLLECTION_ID}`);
      console.log("---------------------------------------");
    });

  } catch (error) {
    console.error(
      "Could not initialize the backend:",
      error
    );

    process.exit(1);
  }
}

startServer();