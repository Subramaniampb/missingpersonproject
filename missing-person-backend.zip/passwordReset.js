const express = require("express");
const crypto = require("crypto");
const bcrypt = require("bcryptjs");
const nodemailer = require("nodemailer");

const {
    DynamoDBDocumentClient,
    GetCommand,
    ScanCommand,
    UpdateCommand
} = require("@aws-sdk/lib-dynamodb");

const router = express.Router();

const USERS_TABLE = process.env.USERS_TABLE || "AppUsers";
const FRONTEND_URL =
    process.env.FRONTEND_URL || "http://localhost:5173";

const transporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: Number(process.env.SMTP_PORT || 465),
    secure: process.env.SMTP_SECURE !== "false",
    auth: {
        user: process.env.SMTP_USER,
        pass: process.env.SMTP_PASS
    }
});

/*
 * Configure this module with the DynamoDB document client
 * already used by your existing backend.
 */
let dynamoDB;

function configurePasswordReset(documentClient) {
    dynamoDB = documentClient;
}

function getClient() {
    if (!dynamoDB) {
        throw new Error(
            "Password reset DynamoDB client is not configured."
        );
    }

    return dynamoDB;
}

async function findUserByEmail(email) {
    const result = await getClient().send(
        new ScanCommand({
            TableName: USERS_TABLE,
            FilterExpression: "email = :email",
            ExpressionAttributeValues: {
                ":email": email
            }
        })
    );

    return (result.Items || []).find(
        user =>
            typeof user.email === "string" &&
            user.email.toLowerCase() === email
    ) || null;
}

/*
 * POST /api/auth/forgot-password
 */
router.post("/forgot-password", async (req, res) => {
    try {
        const email = String(req.body.email || "")
            .trim()
            .toLowerCase();

        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
            return res.status(400).json({
                message: "Please enter a valid email address."
            });
        }

        const user = await findUserByEmail(email);

        /*
         * Use the same response whether or not an account exists.
         */
        const responseMessage =
            "If an account exists for this email, a password-reset link will be sent.";

        if (!user) {
            return res.json({ message: responseMessage });
        }

        if (!user.userId) {
            throw new Error(
                "Expected userId was not found in the user record."
            );
        }

        const token = crypto.randomBytes(32).toString("hex");

        const tokenHash = crypto
            .createHash("sha256")
            .update(token)
            .digest("hex");

        const expiry = Date.now() + 15 * 60 * 1000;

        await getClient().send(
            new UpdateCommand({
                TableName: USERS_TABLE,
                Key: {
                    userId: user.userId
                },
                UpdateExpression:
                    "SET resetTokenHash = :hash, resetTokenExpiry = :expiry",
                ExpressionAttributeValues: {
                    ":hash": tokenHash,
                    ":expiry": expiry
                }
            })
        );

        const resetLink =
            `${FRONTEND_URL}/reset-password?token=${token}`;

        await transporter.sendMail({
            from: process.env.SMTP_USER,
            to: email,
            subject: "Reset your password",
            text:
                "You requested a password reset.\n\n" +
                `Open this link to reset your password:\n${resetLink}\n\n` +
                "The link expires in 15 minutes. " +
                "If you did not request this, ignore this email.",
            html: `
                <h2>Password Reset</h2>
                <p>You requested a password reset.</p>
                <p>
                    <a href="${resetLink}">
                        Reset My Password
                    </a>
                </p>
                <p>This link expires in 15 minutes.</p>
                <p>If you did not request this, ignore this email.</p>
            `
        });

        return res.json({ message: responseMessage });

    } catch (error) {
        console.error("Forgot password error:", error);

        return res.status(500).json({
            message: "Unable to process your request right now."
        });
    }
});

/*
 * POST /api/auth/reset-password
 */
router.post("/reset-password", async (req, res) => {
    try {
        const token = String(req.body.token || "");
        const newPassword = String(req.body.newPassword || "");

        if (!/^[a-f0-9]{64}$/i.test(token)) {
            return res.status(400).json({
                message: "The reset link is invalid or expired."
            });
        }

        if (
            newPassword.length < 8 ||
            newPassword.length > 72
        ) {
            return res.status(400).json({
                message:
                    "Password must contain between 8 and 72 characters."
            });
        }

        const tokenHash = crypto
            .createHash("sha256")
            .update(token)
            .digest("hex");

        const result = await getClient().send(
            new ScanCommand({
                TableName: USERS_TABLE,
                FilterExpression: "resetTokenHash = :hash",
                ExpressionAttributeValues: {
                    ":hash": tokenHash
                }
            })
        );

        const user = (result.Items || []).find(
            item => item.resetTokenHash === tokenHash
        );

        if (
            !user ||
            !user.userId ||
            !user.resetTokenExpiry ||
            Date.now() > Number(user.resetTokenExpiry)
        ) {
            return res.status(400).json({
                message: "The reset link is invalid or expired."
            });
        }

        const passwordHash = await bcrypt.hash(newPassword, 12);

        /*
         * IMPORTANT:
         * This assumes your login code uses passwordHash.
         * If it uses another attribute, the implementation must
         * be made consistent with that existing login code.
         */
        await getClient().send(
            new UpdateCommand({
                TableName: USERS_TABLE,
                Key: {
                    userId: user.userId
                },
                UpdateExpression:
                    "SET passwordHash = :password " +
                    "REMOVE resetTokenHash, resetTokenExpiry",
                ConditionExpression:
                    "resetTokenHash = :hash " +
                    "AND resetTokenExpiry = :expiry " +
                    "AND resetTokenExpiry >= :now",
                ExpressionAttributeValues: {
                    ":password": passwordHash,
                    ":hash": tokenHash,
                    ":expiry": user.resetTokenExpiry,
                    ":now": Date.now()
                }
            })
        );

        return res.json({
            message:
                "Password reset successfully. You can now log in."
        });

    } catch (error) {
        if (error.name === "ConditionalCheckFailedException") {
            return res.status(400).json({
                message: "The reset link is invalid or expired."
            });
        }

        console.error("Reset password error:", error);

        return res.status(500).json({
            message: "Unable to reset your password right now."
        });
    }
});

module.exports = {
    router,
    configurePasswordReset
};